#include "BattleShipApp.h"

int main(){
    BattleShipApp battleShip = BattleShipApp();
    battleShip.Play();
    return 0;
}